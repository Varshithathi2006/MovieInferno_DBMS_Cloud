"use strict";(()=>{var e={};e.id=654,e.ids=[654],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},2615:e=>{e.exports=require("http")},8791:e=>{e.exports=require("https")},8621:e=>{e.exports=require("punycode")},6162:e=>{e.exports=require("stream")},7360:e=>{e.exports=require("url")},1568:e=>{e.exports=require("zlib")},2380:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>m,patchFetch:()=>E,requestAsyncStorage:()=>l,routeModule:()=>c,serverHooks:()=>h,staticGenerationAsyncStorage:()=>p});var a={};r.r(a),r.d(a,{POST:()=>u});var s=r(9303),i=r(8716),o=r(670),d=r(7070),n=r(5228);async function u(){try{console.log("Starting watchlist table schema update...");let{data:e,error:t}=await n.O.from("watchlist").select("*");if(t)return console.error("Error fetching existing watchlist data:",t),d.NextResponse.json({error:"Failed to fetch existing data"},{status:500});console.log(`Found ${e.length} existing watchlist entries`);let r=`
      -- Drop the old watchlist table
      DROP TABLE IF EXISTS watchlist_old;
      
      -- Rename current table to backup
      ALTER TABLE watchlist RENAME TO watchlist_old;
      
      -- Create new watchlist table with proper structure
      CREATE TABLE watchlist (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        tmdb_id INTEGER NOT NULL,
        media_type VARCHAR(10) CHECK (media_type IN ('movie', 'tv')) NOT NULL,
        title VARCHAR(255) NOT NULL,
        poster_path TEXT,
        release_date DATE,
        vote_average DECIMAL(3,1),
        overview TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        UNIQUE(user_id, tmdb_id, media_type)
      );
      
      -- Create indexes for better performance
      CREATE INDEX IF NOT EXISTS idx_watchlist_user_id ON watchlist(user_id);
      CREATE INDEX IF NOT EXISTS idx_watchlist_media_type ON watchlist(media_type);
      CREATE INDEX IF NOT EXISTS idx_watchlist_created_at ON watchlist(created_at);
    `,{error:a}=await n.O.rpc("exec_sql",{sql:r});if(a)return console.error("Error creating new table structure:",a),d.NextResponse.json({message:"Schema update needed but exec_sql not available. Manual database update required.",existingStructure:e.length>0?Object.keys(e[0]):[],requiredColumns:["id","user_id","tmdb_id","media_type","title","poster_path","release_date","vote_average","overview","created_at","updated_at"],recommendation:"Please update the database schema manually or through Supabase dashboard"},{status:200});if(e.length>0){let t=e.map(e=>({user_id:e.user_id,tmdb_id:e.movie_id,media_type:"movie",title:"Migrated Movie",created_at:e.added_date||new Date().toISOString()})),{error:r}=await n.O.from("watchlist").insert(t);if(r)return console.error("Error migrating data:",r),d.NextResponse.json({error:"Failed to migrate existing data"},{status:500})}return d.NextResponse.json({message:"Watchlist table schema updated successfully",migratedRecords:e.length})}catch(e){return console.error("Error updating watchlist schema:",e),d.NextResponse.json({error:"Internal server error"},{status:500})}}let c=new s.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/update-watchlist-schema/route",pathname:"/api/update-watchlist-schema",filename:"route",bundlePath:"app/api/update-watchlist-schema/route"},resolvedPagePath:"C:\\Users\\varshitha-home\\Desktop\\last_hope\\MovieInferno\\app\\api\\update-watchlist-schema\\route.js",nextConfigOutput:"",userland:a}),{requestAsyncStorage:l,staticGenerationAsyncStorage:p,serverHooks:h}=c,m="/api/update-watchlist-schema/route";function E(){return(0,o.patchFetch)({serverHooks:h,staticGenerationAsyncStorage:p})}},5228:(e,t,r)=>{r.d(t,{O:()=>a});let a=(0,r(4738).eI)("https://ajnkisostsjhoqfyjsqu.supabase.co","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFqbmtpc29zdHNqaG9xZnlqc3F1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTYzOTY0MjQsImV4cCI6MjA3MTk3MjQyNH0.KMvKbgeF2xeCwrFSGXHA0NLqZ9_94kIBs0CiSjkuBkg")}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[948,37,70],()=>r(2380));module.exports=a})();